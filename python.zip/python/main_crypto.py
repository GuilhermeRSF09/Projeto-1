from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad
from descriptografia import decrypt
from common import sbox, sub_bytes, shift_rows

# Chave AES de 128 bits (16 bytes)
key = get_random_bytes(16)

def mix_columns(state):
    for i in range(0, 16, 4):
        a = state[i]
        b = state[i + 1]
        c = state[i + 2]
        d = state[i + 3]
        state[i] = a ^ b ^ c ^ d
        state[i + 1] = a ^ b ^ c ^ d
        state[i + 2] = a ^ b ^ c ^ d
        state[i + 3] = a ^ b ^ c ^ d
    return state

def encrypt(plain_text):
    data = pad(plain_text.encode(), AES.block_size)
    blocks = [data[i:i + AES.block_size] for i in range(0, len(data), AES.block_size)]
    encrypted_blocks = []
    for block in blocks:
        state = list(block)
        state = sub_bytes(state)
        state = shift_rows(state)
        # state = mix_columns(state)
        encrypted_block = bytes(state)
        encrypted_blocks.append(encrypted_block)
    encrypted_data = b''.join(encrypted_blocks)
    return encrypted_data

# Exemplo de uso
text_to_encrypt = str(input("Digite a chave: "))
encrypted = encrypt(text_to_encrypt)
print("Texto Criptografado:", encrypted.hex())

