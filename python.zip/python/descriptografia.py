from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from common import sbox, inv_shift_rows, inv_sub_bytes

def inv_mix_columns(state):
    for i in range(0, 16, 4):
        a = state[i]
        b = state[i + 1]
        c = state[i + 2]
        d = state[i + 3]
        state[i] = a ^ b ^ c ^ d
        state[i + 1] = a ^ b ^ c ^ d
        state[i + 2] = a ^ b ^ c ^ d
        state[i + 3] = a ^ b ^ c ^ d
    return state

def decrypt(encrypted_data):
    blocks = [encrypted_data[i:i + AES.block_size] for i in range(0, len(encrypted_data), AES.block_size)]
    decrypted_blocks = []
    for block in blocks:
        state = list(block)
        # state = inv_mix_columns(state)  # Note: this is commented out in your original code
        state = inv_shift_rows(state)
        state = inv_sub_bytes(state)
        decrypted_block = bytes(state)
        decrypted_blocks.append(decrypted_block)
    decrypted_data = b''.join(decrypted_blocks)
    return unpad(decrypted_data, AES.block_size).decode()

if __name__ == "__main__":
    encrypted_data = bytes.fromhex(input("Digite o texto criptografado em formato hexadecimal: "))
    decrypted = decrypt(encrypted_data)
    print("Texto Descriptografado:", decrypted)
